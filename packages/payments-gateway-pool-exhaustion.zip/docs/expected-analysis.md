# Expected analysis for CAU-9001 (payments-gateway-pool-exhaustion)

This document is the ground truth a live demonstration is judged against.
Everything below is derivable from the bundle's own evidence — nothing here
is hard-coded into the pipeline.

## 1. Mechanism detection (analysis layer)

`extract_all_mechanisms` buckets log records by the shared needle sets in
`cauveris/analysis/parameter_registry.py`:

| evidence | matches | mechanism |
|---|---|---|
| `logs/gateway.log`: "connection pool exhausted: active connections 35 exceeded pool capacity 10" | `DB_POOL_NEEDLES` (`connection pool exhausted`) | `connection_pool_exhaustion` |
| "cannot get connection … connection checkout timeout after 5000 ms" | `connection (checkout) timeout` | `connection_pool_exhaustion` (pool wins over generic timeout — pool is checked first) |
| "HikariPool-1 - Connection is not available" | `hikari.*unavailable` | `connection_pool_exhaustion` |
| `logs/postgres.log`: "remaining connection slots are 0", "too many connections" | `DB_POOL_NEEDLES` | `connection_pool_exhaustion` |

Dominant mechanism: **`connection_pool_exhaustion`** (family `database_storage`).

Parameters recovered from the evidence:
- `db_pool_size = 10` — declared by `config/payments.toml` → `[database].max_connections`
  (needle `max_connections`).
- `db_demand_connections = 35` — measured from the log text
  (`active connections 35`) and corroborated by `metrics/connections.csv`
  (`active_connections` peaks at 35).
- `db_connection_timeout_ms = 5000` — declared `connection_timeout_ms`.

## 2. Hypotheses (hypothesis layer)

`HypothesisGenerator._rule_log_patterns` must emit
**`h_connection_pool_exhaustion`** with a structured proposal:

- parameter `db_pool_size`, current `10.0`,
- target `ceil(max(35, 10) * 1.5) = 53`,
- file `config/payments.toml`, config_key `database.max_connections`.

Competing hypotheses may also appear (e.g. arrival overload from
`metrics/http.csv`, server overload from `worker_count = 4` vs ~1000 rps) —
the audit actually *expects* more than one. What must not happen: a memory
hypothesis (no OOM needles anywhere, host memory flat) or a lock hypothesis
(no lock needles), and no patch that *raises a deadline to hide a slow
dependency*.

When `NEBIUS_API_KEY` is active, the `HYPOTHESIS_PROPOSAL` task adds a
model-generated hypothesis `hyp-CAU-9001-nebius` whose `causal_claim` should
name the pool exhaustion and cite the log/metric artifacts; its confidence is
capped at 0.85 and its id is derived from incident + provider, never from the
model's own choice.

## 3. Simulation (digital twin)

- Baseline reproduces the failure: with `db_pool_size=10` and demand 35,
  checkout demand > capacity → the twin reports pool exhaustion
  (`failure_oracle.hypothesis_supported = true` on the baseline arm).
- Intervention `db_pool_size=53`: 53 ≥ 35 → exhaustion cleared
  (`hypothesis_supported = false` / invariant satisfied on the patched arm).

## 4. Patch

`PatchGenerator` emits a parser-aware unified diff against the customer's own
file — one line, quoting/comment style preserved:

```diff
--- a/config/payments.toml
+++ b/config/payments.toml
@@ [database] section
-max_connections = 10
+max_connections = 53
```

The diff must reference `config/payments.toml` (a file the bundle shipped).

## 5. Verification (9-point engine)

`VerificationEngine` stages the patch in a sandbox workspace and runs the
atomic checks; for this mechanism the pivotal check is:

- `patched db_pool_size (53) >= db_demand_connections (35)` — PASS;
- reversibility: applying `rollback.patch` restores the original bytes — PASS;
- the full run reports `checks_passed = 9` and `verified = true`.

## 6. Repair package (download)

`GET /api/v1/incidents/{id}/download-patch-package` returns a zip with
`manifest.json` (`verification_level: verified`), `patch.patch`, `fix.patch`,
`rollback.patch`, `rollback.sh`, `diagnosis.json`, `diagnosis.md`,
`provenance.json`, `capability-report.json`, `baseline-results.json`,
`post-intervention-results.json`, `verification-report.json`, `limitations.md`,
`application-instructions.md`, `checksums.sha256` — and every line of
`checksums.sha256` must match the SHA-256 of the archived bytes.
