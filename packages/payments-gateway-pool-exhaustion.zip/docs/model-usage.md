# Model usage (Nebius Token Factory / NVIDIA Nemotron) for this package

Cauveris talks to the hosted model through exactly one gateway
(`cauveris/model_gateway/nebius.py`) and exactly one pipeline stage calls it
(the hypothesis stage). This page lists every knob so a live demo spends
credits only where you want them to.

## Environment variables (read from the real process environment first; `.env` is a fallback)

| variable | default | effect |
|---|---|---|
| `NEBIUS_API_KEY` / `CAUVERIS_NEBIUS_API_KEY` | — | enables the `NebiusModelGateway` when combined with `nebius_enabled`. **Never printed; scrubbed from prompts sent to the model.** |
| `CAUVERIS_NEBIUS_ENABLED` | `true` when a key exists | master switch. Set `CAUVERIS_NEBIUS_ENABLED=false` in the *real* environment to guarantee **zero** Nebius calls even though `.env` contains a key (dotenv does not override existing env vars). |
| `NEBIUS_BASE_URL` | `https://api.tokenfactory.nebius.com/v1` | API base. |
| `NEBIUS_MODEL_ID` | `nvidia/Llama-3.1-Nemotron-70B-Instruct-HF` | chat model used for `HYPOTHESIS_PROPOSAL`. |
| `NEBIUS_MODEL_FAST` | `nvidia/nemotron-mini-4b-instruct` | cheap model for the other registered tasks. |
| `NEBIUS_MODEL_REASONING` | `nvidia/Nemotron-4-340B-Instruct` | escalation model. |
| `CAUVERIS_MODEL_DAILY_BUDGET_USD` | e.g. `5.0` | hard daily spend cap; the circuit breaker opens past it (`daily_spend` in `/api/v1/model-health`). |
| `CAUVERIS_MODEL_CIRCUIT_BREAKER_FAILURES` | `3` | consecutive failures before the provider is opened. |
| `CAUVERIS_MODEL_TIMEOUT_SECONDS` | `120` | per-request timeout. |

## Where the calls land

- **Only** `ModelTaskType.HYPOTHESIS_PROPOSAL` is invoked by the pipeline
  (`cauveris/model_gateway/tasks.py::TASK_REGISTRY`), from
  `HypothesisGenerator._gateway_hypothesis()` during `reconstruct`.
- Every call is recorded: `GET /api/v1/incidents/{id}/model-executions`
  (task, provider, model, latency ms, input/output tokens, est. cost USD,
  success/error, hypothesis id produced).
- Provider-wide health: `GET /api/v1/model-health` — per-provider status,
  circuit-breaker state, `daily_spend` vs budget.

## Two demo modes (scripts/demo_incident_package.py)

```bash
# 1) deterministic / zero-spend — strips NEBIUS_API_KEY and sets
#    CAUVERIS_NEBIUS_ENABLED=false for the spawned backend:
python scripts/demo_incident_package.py --package packages/payments-gateway-pool-exhaustion --start-backend

# 2) live model — forwards the key; the single HYPOTHESIS_PROPOSAL call goes
#    to Nebius Token Factory and yields hyp-CAU-9001-nebius:
python scripts/demo_incident_package.py --package packages/payments-gateway-pool-exhaustion --start-backend --live-model
```

Recommended order before a live video: run mode 1 locally until every assertion
in `docs/expected-analysis.md` passes (no credits spent), then flip to mode 2
once, watch `/api/v1/model-health` `daily_spend`, and use the resulting
`hyp-CAU-9001-nebius` hypothesis + `model-executions` entry in the demo.

## Cost shape for one run

One pipeline run = **one** model request for this package
(`HYPOTHESIS_PROPOSAL`, prompt built from the bundle, JSON-schema response —
a few thousand input tokens, a few hundred output tokens). With a $29
budget, dozens of deterministic runs are free; each live run is a single
bounded call whose cost is reported back in `model-executions.estimated_cost_usd`
and accumulates into `daily_spend`.
