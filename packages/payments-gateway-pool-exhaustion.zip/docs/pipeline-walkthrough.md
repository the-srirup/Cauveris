# Pipeline walkthrough for `payments-gateway-pool-exhaustion` (CAU-9001)

What happens, stage by stage, from upload to a downloadable repair package.
Stage names are the canonical ones in
`cauveris/state_machine/persistence.py::CANONICAL_STAGE_DEFINITIONS` and are the
states you will see stream on `GET /api/v1/incidents/{id}/events`.

## HTTP flow

1. `POST /api/v1/auth/login` — demo mode (`CAUVERIS_DEMO_MODE=true`,
   `CAUVERIS_DEMO_AUTH=true`): `demo@cauveris.local` / `demo123456`.
2. `POST /api/v1/incidents` — body `{"custom_id": "CAU-9001"}` → incident id.
3. `POST /api/v1/incidents/{id}/upload` — multipart field `file` =
   `payments-gateway-pool-exhaustion.zip` (limits: ≤100 MB zipped,
   ≤10 000 members, ≤512 MB uncompressed).
4. `POST /api/v1/incidents/{id}/validate` — archive safety + manifest schema.
5. `POST /api/v1/incidents/{id}/reconstruct` — kicks the pipeline off.
6. Poll `GET /api/v1/incidents/{id}/events` (or listen on
   `GET /api/v1/incidents/{id}/stream`, SSE) until `state == SUCCESS`.
7. Read `GET /api/v1/incidents/{id}/hypotheses`, `/experiments`, `/patches`.
8. Download: `GET /api/v1/incidents/{id}/download-patch-package`.

## Stage-by-stage

| # | stage | what happens for CAU-9001 |
|---|---|---|
| 1 | `incident_ingested` | zip is unpacked safely; every member checksummed (zip-slip, member-count and size caps enforced). |
| 2 | `evidence_inventory` | `manifest.yaml` is parsed; files are bucketed: `config/payments.toml` + `config/routes.json` → configs, `logs/*` → logs, `metrics/*.csv` (`active_connections`, `pool_capacity`, `rps`, … timestamped columns) → metrics, `traces/otel.json` → spans, `observations/operator_note.md` + `README.md` → prose notes, `source/gateway/*` → source. |
| 3 | `evidence_extracted` | configs parsed; log lines classified into mechanism buckets — pool needles dominate (`connection pool exhausted`, `HikariPool…timed out`, `remaining connection slots are 0`). |
| 4 | `timeline_built` | events from logs/metrics/traces/deployments merged into one UTC timeline: traffic spike 17:55 → pool exhaustion 18:00 → deploy v17 (cache TTL) at 17:45. |
| 5 | `invariants_derived` | parameter registry maps evidence to parameters: `db_pool_size=10` (`database.max_connections`), demand `db_demand_connections=35`, `db_connection_timeout_ms=5000`. |
| 6 | `model_assistance` | **model stage** — see below. |
| 7 | `hypotheses_generated` | `_rule_log_patterns` emits `h_connection_pool_exhaustion` (current 10 → proposed `ceil(35*1.5)=53`, file `config/payments.toml`); competing overload hypotheses may be added; with a live key, `hyp-CAU-9001-nebius` arrives here too. |
| 8 | `capability_planning` | which knobs are patchable, reversible, and inside the allowed file set. |
| 9 | `baseline_simulated` | digital twin replays the bundle with `max_connections=10` → pool exhaustion reproduced (`hypothesis_supported=true` on baseline). |
| 10 | `counterfactual_intervention` | twin replays with `max_connections=53` → 53 ≥ 35, exhaustion cleared. |
| 11 | `patch_generated` | parser-aware unified diff on `config/payments.toml`: `max_connections = 10` → `53`, plus rollback to 10. |
| 12 | `patch_staged` | patch applied to a sandbox copy of the bundle; no-op if it does not apply. |
| 13 | `verification_executed` | 9-point engine; pivotal check: patched pool ≥ measured demand. Expect `checks_passed=9`, `verified=true`. |
| 14 | `report_generated` | `diagnosis.md`, provenance, capability report, limitations. |
| 15 | `package_ready` | repair zip assembled; `GET .../download-patch-package` serves it; `checksums.sha256` inside matches archive bytes. |

## The model stage in detail (`model_assistance` / `hypotheses_generated`)

- Trigger: `create_model_gateway()` appends a `NebiusModelGateway` only when
  `nebius_api_key` is set **and** `nebius_enabled` is true.
- Only one pipeline stage actually calls the model: `HypothesisGenerator.
  _gateway_hypothesis()` → `model_gateway.generate(prompt, schema=Hypothesis,
  task_type=ModelTaskType.HYPOTHESIS_PROPOSAL)`.
- The prompt is built from the evidence bundle (mechanisms, timeline, top log
  lines, candidate parameters) with secrets scrubbed; the request uses JSON
  `response_format` against the task schema (`Hypothesis`), with a bounded
  token budget from `TASK_REGISTRY`.
- Nebius endpoint: `https://api.tokenfactory.nebius.com/v1/chat/completions`;
  default models `NEBIUS_MODEL_ID` =
  `nvidia/Llama-3.1-Nemotron-70B-Instruct-HF` (reasoning fallback:
  `NEBIUS_MODEL_REASONING` = `nvidia/Nemotron-4-340B-Instruct`).
- Result: hypothesis id `hyp-CAU-9001-nebius`, `provider="nebius"`, confidence
  clamped to ≤0.85, stored next to the rule-based hypotheses; the call is
  recorded in `GET /api/v1/incidents/{id}/model-executions` with latency,
  tokens, estimated cost; provider health + daily spend + circuit breaker:
  `GET /api/v1/model-health`.
- Without a key: `model_assistance_status` is reported as local/unavailable and
  **no** `nebius` hypothesis is fabricated — the deterministic path still
  produces the patch and verification.
